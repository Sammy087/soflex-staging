
// $(document).ready(function () {
//     $("#updatepatient").click(function (e) {
//         e.preventDefault();
//         patientcollection.doc(patientid.value).update({
//           patient_Name: patientname.value,
//           patient_MEDREC: patientmedrec.value,
//           patient_tretstart: tretstart.value,
//           patient_tretEnd: tretEnd.value,
//           patient_tretDuration: Number(tretDuration.value),
//           patient_DoctorName: DoctorName.value,
//           patient_DocNum: Number(DocNum.value),
//           patient_HospitalName: HospitalName.value,
//           patient_HospitalLocation: HospitalLocation.value,
//           patient_preDisease: preDisease.value,
//           patient_presTiming: presTiming.value,
//           patient_presDur: presDur.value
//         }).then(() => { console.log("Updated successfully"); })
//           .catch(error => { console.error(error) });
//       });
    
//       $("#updatepatient").click(function (e) {
//         e.preventDefault();
//         highriskcollection.doc(patientid.value).update({
//           patient_Name: patientname.value,
//           patient_MEDREC: patientmedrec.value,
//           patient_tretstart: tretstart.value,
//           patient_tretEnd: tretEnd.value,
//           patient_tretDuration: Number(tretDuration.value),
//           patient_DoctorName: DoctorName.value,
//           patient_DocNum: Number(DocNum.value),
//           patient_HospitalName: HospitalName.value,
//           patient_HospitalLocation: HospitalLocation.value,
//           patient_preDisease: preDisease.value,
//           patient_presTiming: presTiming.value,
//           patient_presDur: presDur.value
//         }).then(() => { console.log("Updated successfully"); })
//           .catch(error => { console.error(error) });
    
//       });
    
//       $("#updatepatient").click(function (e) {
//         e.preventDefault();
//         lowriskcollection.doc(patientid.value).update({
//           patient_Name: patientname.value,
//           patient_MEDREC: patientmedrec.value,
//           patient_tretstart: tretstart.value,
//           patient_tretEnd: tretEnd.value,
//           patient_tretDuration: Number(tretDuration.value),
//           patient_DoctorName: DoctorName.value,
//           patient_DocNum: Number(DocNum.value),
//           patient_HospitalName: HospitalName.value,
//           patient_HospitalLocation: HospitalLocation.value,
//           patient_preDisease: preDisease.value,
//           patient_presTiming: presTiming.value,
//           patient_presDur: presDur.value
//         }).then(() => { console.log("Updated successfully"); })
//           .catch(error => { console.error(error) });
    
//       });
    
    
//       $("#updatepatient").click(function (e) {
//         e.preventDefault();
//         attentioncollection.doc(patientid.value).update({
//           patient_Name: patientname.value,
//           patient_MEDREC: patientmedrec.value,
//           patient_tretstart: tretstart.value,
//           patient_tretEnd: tretEnd.value,
//           patient_tretDuration: Number(tretDuration.value),
//           patient_DoctorName: DoctorName.value,
//           patient_DocNum: Number(DocNum.value),
//           patient_HospitalName: HospitalName.value,
//           patient_HospitalLocation: HospitalLocation.value,
//           patient_preDisease: preDisease.value,
//           patient_presTiming: presTiming.value,
//           patient_presDur: presDur.value
//         }).then(() => { console.log("Updated successfully"); })
//           .catch(error => { console.error(error) });
    
//       });

//     });