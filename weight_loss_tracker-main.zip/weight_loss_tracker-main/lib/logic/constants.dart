const double KG_LBS_RATIO = 2.2;
const int MAX_KG_VALUE = 200;
const int MIN_KG_VALUE = 0;